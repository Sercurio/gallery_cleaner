import 'package:flutter/material.dart';

class ImageSwipe {
  String uri;
  DateTime date;
  Image image;

  ImageSwipe({this.uri, this.image, this.date});
}
